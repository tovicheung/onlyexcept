import setuptools

setuptools.setup(
    name="onlyexcept",
    version="0.0.1",
    author="tovicheung",
    description="catch only a specific type of exception",
    packages=["onlyexcept"]
)